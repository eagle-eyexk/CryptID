-- Trigger to auto-create profile when user signs up
-- Note: DNA key hash and username are passed via user metadata during signup

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (
    id, 
    username, 
    display_name, 
    dna_key_hash,
    crypid_genesis_hash,
    birth_timestamp
  )
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'username', 'user_' || substr(new.id::text, 1, 8)),
    coalesce(new.raw_user_meta_data ->> 'display_name', null),
    coalesce(new.raw_user_meta_data ->> 'dna_key_hash', ''),
    coalesce(new.raw_user_meta_data ->> 'crypid_genesis_hash', ''),
    now()
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

-- Drop existing trigger if exists
drop trigger if exists on_auth_user_created on auth.users;

-- Create trigger
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
