-- CrypId-ADN Database Schema
-- Creates profiles table with DNA key for recovery

-- Create profiles table linked to auth.users
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  dna_key_hash text not null, -- Hashed DNA recovery key
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  -- CrypId-ADN specific fields
  crypid_genesis_hash text, -- The genesis hash of the CrypId
  evolution_generation integer default 0,
  birth_timestamp timestamp with time zone default now()
);

-- Enable Row Level Security
alter table public.profiles enable row level security;

-- RLS Policies
create policy "profiles_select_own" on public.profiles 
  for select using (auth.uid() = id);

create policy "profiles_insert_own" on public.profiles 
  for insert with check (auth.uid() = id);

create policy "profiles_update_own" on public.profiles 
  for update using (auth.uid() = id);

create policy "profiles_delete_own" on public.profiles 
  for delete using (auth.uid() = id);

-- Allow checking username availability without auth
create policy "profiles_check_username" on public.profiles 
  for select using (true);

-- Create index for username lookups
create index if not exists profiles_username_idx on public.profiles (username);

-- Create index for DNA key recovery lookups (we need service role for this)
create index if not exists profiles_dna_key_hash_idx on public.profiles (dna_key_hash);
