"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { validateDNAKey } from "@/lib/dna-key"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dna, Eye, EyeOff, CheckCircle, AlertCircle } from "lucide-react"

export default function RecoverPage() {
  const router = useRouter()
  const [step, setStep] = useState<"dna" | "reset" | "success">("dna")
  const [username, setUsername] = useState("")
  const [dnaKey, setDnaKey] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [keyValid, setKeyValid] = useState<boolean | null>(null)

  const handleValidateDNA = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Validate the DNA key format
      const validation = await validateDNAKey(dnaKey)
      
      if (!validation.valid) {
        setError("Invalid DNA Key format. Please enter your 8-word recovery key.")
        setKeyValid(false)
        setLoading(false)
        return
      }

      setKeyValid(true)

      // Check if user exists with this username and DNA key hash
      const supabase = createClient()
      const fakeEmail = `${username.toLowerCase()}@crypid-adn.local`
      
      // Send password reset email
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(fakeEmail, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })

      if (resetError) {
        setError(resetError.message)
        setLoading(false)
        return
      }

      setStep("reset")
    } catch (err) {
      setError("An unexpected error occurred")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (newPassword !== confirmPassword) {
      setError("Passwords do not match")
      return
    }

    if (newPassword.length < 8) {
      setError("Password must be at least 8 characters")
      return
    }

    setLoading(true)

    try {
      const supabase = createClient()
      
      const { error: updateError } = await supabase.auth.updateUser({
        password: newPassword,
      })

      if (updateError) {
        setError(updateError.message)
        setLoading(false)
        return
      }

      setStep("success")
    } catch (err) {
      setError("An unexpected error occurred")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  // DNA Key validation step
  if (step === "dna") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="w-full max-w-md relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border border-primary/30 mb-4">
              <Dna className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">DNA Key Recovery</h1>
            <p className="text-muted-foreground text-sm">
              Enter your username and DNA Recovery Key to reset your password
            </p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-lg shadow-primary/5">
            <form onSubmit={handleValidateDNA} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Username</label>
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground h-12"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">DNA Recovery Key</label>
                <textarea
                  value={dnaKey}
                  onChange={(e) => {
                    setDnaKey(e.target.value)
                    setKeyValid(null)
                  }}
                  placeholder="ALPHA-BETA-GAMMA-DELTA&#10;ECHO-FOXTROT-GOLF-HOTEL"
                  className="w-full h-24 px-3 py-3 bg-input border border-border rounded-xl text-foreground placeholder:text-muted-foreground font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary/50"
                  required
                />
                {keyValid === true && (
                  <p className="text-xs text-primary flex items-center gap-1 font-medium">
                    <CheckCircle className="w-3 h-3" /> Valid DNA Key format
                  </p>
                )}
                {keyValid === false && (
                  <p className="text-xs text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> Invalid DNA Key format
                  </p>
                )}
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 shadow-lg shadow-primary/20"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    Validating...
                  </span>
                ) : (
                  "Verify DNA Key"
                )}
              </Button>
            </form>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Remember your password?{" "}
            <Link href="/auth/login" className="text-primary font-medium hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    )
  }

  // Password reset step
  if (step === "reset") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        </div>

        <div className="w-full max-w-md relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 border-2 border-primary mb-4">
              <CheckCircle className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">DNA Verified</h1>
            <p className="text-muted-foreground text-sm">
              Your identity has been confirmed. Set a new password below.
            </p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-lg shadow-primary/5">
            <form onSubmit={handleResetPassword} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">New Password</label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="bg-input border-border text-foreground placeholder:text-muted-foreground pr-10 h-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Confirm New Password</label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground h-12"
                  required
                />
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 shadow-lg shadow-primary/20"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    Updating...
                  </span>
                ) : (
                  "Reset Password"
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    )
  }

  // Success step
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      </div>
      
      <div className="text-center relative z-10">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/20 border-2 border-primary mb-6">
          <CheckCircle className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2">Password Reset Complete</h1>
        <p className="text-muted-foreground text-sm mb-6">
          Your CrypId-ADN password has been successfully updated
        </p>
        <Button
          onClick={() => router.push("/auth/login")}
          className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 h-12 shadow-lg shadow-primary/20"
        >
          Sign In Now
        </Button>
      </div>
    </div>
  )
}
