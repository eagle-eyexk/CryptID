"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { generateDNAKey, type DNAKey } from "@/lib/dna-key"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DNAHelix } from "@/components/dna-helix"
import { Dna, Copy, Check, Eye, EyeOff, AlertTriangle, Download } from "lucide-react"

export default function RegisterPage() {
  const router = useRouter()
  const [step, setStep] = useState<"form" | "birth" | "dna-reveal">("form")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [dnaKey, setDnaKey] = useState<DNAKey | null>(null)
  const [copied, setCopied] = useState(false)
  const [birthProgress, setBirthProgress] = useState(0)
  const [confirmed, setConfirmed] = useState(false)
  const [downloaded, setDownloaded] = useState(false)

  // Birth ceremony animation
  useEffect(() => {
    if (step === "birth") {
      const interval = setInterval(() => {
        setBirthProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval)
            setTimeout(() => setStep("dna-reveal"), 500)
            return 100
          }
          return prev + 2
        })
      }, 50)
      return () => clearInterval(interval)
    }
  }, [step])

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      return
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters")
      return
    }

    if (username.length < 3) {
      setError("Username must be at least 3 characters")
      return
    }

    // Check for valid username format
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      setError("Username can only contain letters, numbers, and underscores")
      return
    }

    setLoading(true)

    try {
      // Generate DNA key first
      const key = await generateDNAKey()
      setDnaKey(key)

      const supabase = createClient()
      
      // Use username as email with a dummy domain for Supabase auth
      const fakeEmail = `${username.toLowerCase()}@crypid-adn.local`
      
      const { error: signUpError } = await supabase.auth.signUp({
        email: fakeEmail,
        password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || 
            `${window.location.origin}/dashboard`,
          data: {
            username,
            dna_key_hash: key.hash,
          },
        },
      })

      if (signUpError) {
        if (signUpError.message.includes("already registered")) {
          setError("Username already taken. Please choose another.")
        } else {
          setError(signUpError.message)
        }
        setLoading(false)
        return
      }

      // Start birth ceremony
      setStep("birth")
    } catch (err) {
      setError("An unexpected error occurred")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const copyDNAKey = async () => {
    if (dnaKey) {
      await navigator.clipboard.writeText(dnaKey.words.join("-"))
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const downloadDNAKey = () => {
    if (dnaKey) {
      const content = `CrypId-ADN Recovery Key
========================
Username: ${username}
Generated: ${new Date().toISOString()}

YOUR DNA RECOVERY KEY (8 words):
${dnaKey.words.join(" - ")}

IMPORTANT: Keep this file safe and private.
This is your ONLY way to recover your account.
Never share this with anyone.
========================`
      
      const blob = new Blob([content], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `crypid-adn-recovery-${username}.txt`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      setDownloaded(true)
    }
  }

  const handleComplete = () => {
    router.push("/dashboard")
  }

  // Form step
  if (step === "form") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="w-full max-w-md relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border border-primary/30 mb-4">
              <Dna className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">Birth Your CrypId</h1>
            <p className="text-muted-foreground text-sm">
              Begin your journey into digital genetic identity
            </p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-lg shadow-primary/5">
            <form onSubmit={handleRegister} className="space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Username</label>
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose your identity"
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground h-12"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Password</label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create secure password"
                    className="bg-input border-border text-foreground placeholder:text-muted-foreground pr-10 h-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Confirm Password</label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm your password"
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground h-12"
                  required
                />
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 shadow-lg shadow-primary/20"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    Initiating Birth...
                  </span>
                ) : (
                  "Begin Birth Ceremony"
                )}
              </Button>
            </form>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have a CrypId?{" "}
            <Link href="/auth/login" className="text-primary font-medium hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    )
  }

  // Birth ceremony step
  if (step === "birth") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl animate-pulse" />
        </div>
        
        <div className="text-center relative z-10">
          <div className="w-48 h-48 mx-auto mb-8 relative">
            <DNAHelix />
            <div className="absolute inset-0 flex items-center justify-center">
              <div 
                className="w-32 h-32 rounded-full border-4 border-primary/30"
                style={{
                  background: `conic-gradient(var(--primary) ${birthProgress}%, transparent ${birthProgress}%)`,
                }}
              />
            </div>
          </div>
          
          <h2 className="text-xl font-bold text-foreground mb-2">
            Birth Ceremony in Progress
          </h2>
          <p className="text-muted-foreground text-sm mb-4">
            Generating your unique genetic identity...
          </p>
          
          <div className="font-mono text-xs text-primary space-y-1">
            {birthProgress > 10 && <p>Collecting entropy sources...</p>}
            {birthProgress > 30 && <p>Assembling chromosome pairs...</p>}
            {birthProgress > 50 && <p>Encoding genetic sequence...</p>}
            {birthProgress > 70 && <p>Generating recovery DNA key...</p>}
            {birthProgress > 90 && <p>Finalizing CrypId-ADN birth...</p>}
          </div>
          
          <div className="mt-6 text-3xl font-bold text-primary">
            {birthProgress}%
          </div>
        </div>
      </div>
    )
  }

  // DNA Key reveal step
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>
      
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 border-2 border-primary mb-4">
            <Dna className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Your CrypId is Born!
          </h1>
          <p className="text-muted-foreground text-sm">
            Save your DNA Recovery Key - this is your ONLY way to recover your account
          </p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 mb-6 shadow-lg shadow-primary/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">DNA Recovery Key</h3>
            <button
              onClick={copyDNAKey}
              className="flex items-center gap-1 text-xs text-primary hover:text-primary/80 font-medium"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
          
          <div className="bg-input rounded-xl p-4 font-mono text-sm text-primary border-2 border-primary/20">
            {dnaKey?.words.slice(0, 4).join(" - ")}
            <br />
            {dnaKey?.words.slice(4, 8).join(" - ")}
          </div>

          <Button
            onClick={downloadDNAKey}
            className="w-full mt-4 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 font-medium h-11"
            variant="outline"
          >
            <Download className="w-4 h-4 mr-2" />
            {downloaded ? "Downloaded!" : "Download Recovery Key"}
          </Button>

          <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 flex gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-amber-800">
              <strong className="text-amber-900">Critical:</strong> Write down these 8 words in order. 
              This is your only way to recover your account if you forget your password. 
              Store it somewhere safe and never share it.
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <label className="flex items-start gap-3 cursor-pointer p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-0.5 w-5 h-5 rounded border-border text-primary focus:ring-primary accent-primary"
            />
            <span className="text-sm text-muted-foreground">
              I have securely saved my DNA Recovery Key and understand that losing it means 
              I cannot recover my account.
            </span>
          </label>

          <Button
            onClick={handleComplete}
            disabled={!confirmed || !downloaded}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 disabled:opacity-50 shadow-lg shadow-primary/20"
          >
            Complete Registration
          </Button>
          
          {!downloaded && (
            <p className="text-xs text-center text-muted-foreground">
              Please download your recovery key before continuing
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
