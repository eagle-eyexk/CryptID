import Link from "next/link"
import { Dna, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function VerifyPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 border border-primary/30 mb-6">
          <Mail className="w-10 h-10 text-primary" />
        </div>
        
        <h1 className="text-2xl font-bold text-foreground mb-3">
          Verify Your Email
        </h1>
        
        <p className="text-muted-foreground mb-6">
          We have sent a verification link to your email address. 
          Click the link to activate your CrypId-ADN and complete the birth process.
        </p>

        <div className="bg-card border border-border rounded-xl p-6 mb-6">
          <div className="flex items-center gap-3 text-left">
            <Dna className="w-8 h-8 text-primary flex-shrink-0" />
            <div>
              <h3 className="font-medium text-foreground text-sm">Your CrypId is Ready</h3>
              <p className="text-xs text-muted-foreground">
                Once verified, your genetic identity will be fully activated
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Did not receive the email? Check your spam folder or try again.
          </p>
          
          <Link href="/auth/login">
            <Button 
              variant="outline" 
              className="w-full border-border text-foreground hover:bg-card py-6"
            >
              Return to Sign In
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
