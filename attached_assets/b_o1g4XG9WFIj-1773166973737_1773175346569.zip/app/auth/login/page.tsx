"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dna, Eye, EyeOff, Fingerprint, Smartphone } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [biometricAvailable, setBiometricAvailable] = useState(false)
  const [biometricLoading, setBiometricLoading] = useState(false)

  useEffect(() => {
    // Check if WebAuthn/biometric is available
    if (window.PublicKeyCredential) {
      PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then((available) => setBiometricAvailable(available))
        .catch(() => setBiometricAvailable(false))
    }
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const supabase = createClient()
      
      // Use username as email with dummy domain
      const fakeEmail = `${username.toLowerCase()}@crypid-adn.local`
      
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: fakeEmail,
        password,
      })

      if (signInError) {
        if (signInError.message.includes("Invalid login")) {
          setError("Invalid username or password")
        } else {
          setError(signInError.message)
        }
        setLoading(false)
        return
      }

      router.push("/dashboard")
      router.refresh()
    } catch (err) {
      setError("An unexpected error occurred")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleBiometricAuth = async () => {
    if (!biometricAvailable) return
    
    setBiometricLoading(true)
    setError("")

    try {
      // Check for stored credentials
      const storedUsername = localStorage.getItem("crypid_biometric_username")
      
      if (!storedUsername) {
        setError("No biometric login configured. Please sign in with username and password first, then enable biometric in settings.")
        setBiometricLoading(false)
        return
      }

      // Request biometric verification
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge: new Uint8Array(32),
          timeout: 60000,
          userVerification: "required",
          rpId: window.location.hostname,
        },
      }) as PublicKeyCredential | null

      if (credential) {
        // Biometric verified - retrieve stored session
        const storedPassword = sessionStorage.getItem("crypid_temp_auth")
        
        if (storedPassword) {
          const supabase = createClient()
          const fakeEmail = `${storedUsername.toLowerCase()}@crypid-adn.local`
          
          const { error: signInError } = await supabase.auth.signInWithPassword({
            email: fakeEmail,
            password: storedPassword,
          })

          if (!signInError) {
            router.push("/dashboard")
            router.refresh()
            return
          }
        }
        
        // Fallback: show message to login manually
        setError("Biometric verified. Please enter your password to complete login.")
        setUsername(storedUsername)
      }
    } catch (err) {
      console.error("Biometric auth error:", err)
      setError("Biometric authentication cancelled or failed")
    } finally {
      setBiometricLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border border-primary/30 mb-4">
            <Dna className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Welcome Back</h1>
          <p className="text-muted-foreground text-sm">
            Sign in to access your CrypId-ADN
          </p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-lg shadow-primary/5">
          {/* Biometric Auth Button */}
          {biometricAvailable && (
            <>
              <Button
                type="button"
                onClick={handleBiometricAuth}
                disabled={biometricLoading}
                className="w-full bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 font-medium h-14 mb-4"
                variant="outline"
              >
                {biometricLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                    Verifying...
                  </span>
                ) : (
                  <span className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Fingerprint className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold">Face ID / Biometric</div>
                      <div className="text-xs text-muted-foreground">Quick secure login</div>
                    </div>
                  </span>
                )}
              </Button>
              
              <div className="flex items-center gap-3 my-5">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-muted-foreground font-medium">or use password</span>
                <div className="flex-1 h-px bg-border" />
              </div>
            </>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Username</label>
              <Input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="bg-input border-border text-foreground placeholder:text-muted-foreground h-12"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Password</label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="bg-input border-border text-foreground placeholder:text-muted-foreground pr-10 h-12"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 shadow-lg shadow-primary/20"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Authenticating...
                </span>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>
        </div>

        <div className="mt-6 space-y-3">
          <Link 
            href="/auth/recover" 
            className="block text-center text-sm text-primary font-medium hover:underline"
          >
            Forgot password? Recover with DNA Key
          </Link>
          
          <p className="text-center text-sm text-muted-foreground">
            {"Don't have a CrypId? "}
            <Link href="/auth/register" className="text-primary font-medium hover:underline">
              Birth one now
            </Link>
          </p>
        </div>
        
        {/* Device Info */}
        <div className="mt-8 flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Smartphone className="w-4 h-4" />
          <span>Secure login with device authentication</span>
        </div>
      </div>
    </div>
  )
}
