"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Zap } from "lucide-react"
import { TerminalText } from "@/components/terminal-text"
import { FeatureBadges } from "@/components/feature-badges"
import { Button } from "@/components/ui/button"
import { DNAHelix } from "@/components/dna-helix"

export default function CrypIdPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-background px-4">
      {/* Background grid effect */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(34,197,94,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(34,197,94,0.08)_1px,transparent_1px)] bg-[size:50px_50px] pointer-events-none" />
      
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[radial-gradient(circle,rgba(34,197,94,0.15)_0%,transparent_70%)] pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center text-center max-w-3xl mx-auto">
        {/* Logo */}
        <div className="mb-8 flex items-center gap-2">
          <span className="text-foreground/80 text-sm tracking-wider">Hercules App</span>
          <Zap className="w-5 h-5 text-primary fill-primary" />
        </div>

        {/* DNA Helix Animation */}
        <div className="mb-8">
          <DNAHelix />
        </div>

        {/* Main Title */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-4">
          <span className="text-primary">CrypId</span>
          <span className="text-foreground">-ADN</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-muted-foreground mb-8 tracking-wide">
          The Living Identity Protocol
        </p>

        {/* Feature Badges */}
        <FeatureBadges />

        {/* Terminal Text */}
        <TerminalText />

        {/* Auth Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row gap-4">
          <Link href="/auth/login">
            <Button 
              size="lg"
              className="px-8 py-6 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 transition-all duration-300 w-full sm:w-auto"
            >
              Sign In
            </Button>
          </Link>
          <Link href="/auth/register">
            <Button 
              size="lg"
              variant="outline"
              className="px-8 py-6 text-base font-semibold border-2 border-primary/40 text-primary hover:bg-primary/10 hover:border-primary/60 rounded-xl transition-all duration-300 w-full sm:w-auto"
            >
              Birth Your CrypId
            </Button>
          </Link>
        </div>

        {/* Tagline */}
        <p className="mt-12 text-sm text-muted-foreground italic">
          Your identity is born. Not created.
        </p>

        {/* Footer */}
        <footer className="mt-16 text-xs text-muted-foreground/60">
          Built with <span className="text-primary">Hercules</span>
        </footer>
      </div>
    </main>
  )
}
