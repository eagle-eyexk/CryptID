"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { generateChromosomeData } from "@/lib/dna-key"
import { Button } from "@/components/ui/button"
import { DNAHelix } from "@/components/dna-helix"
import { 
  Dna, 
  Shield, 
  Zap, 
  Users, 
  Settings, 
  LogOut,
  Activity,
  Lock,
  Globe,
  ChevronRight,
  MessageSquare
} from "lucide-react"
import type { User } from "@supabase/supabase-js"

interface DashboardClientProps {
  user: User
}

export function DashboardClient({ user }: DashboardClientProps) {
  const router = useRouter()
  const [chromosomes, setChromosomes] = useState<{ id: number; color: string; activity: number }[]>([])
  const [activeTab, setActiveTab] = useState<"overview" | "messages" | "genes" | "settings">("overview")

  useEffect(() => {
    setChromosomes(generateChromosomeData())
  }, [])

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
    router.refresh()
  }

  const username = user.user_metadata?.username || user.email?.split("@")[0] || "User"
  const birthDate = new Date(user.created_at).toLocaleDateString()

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Dna className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-bold text-foreground text-sm">CrypId-ADN</h1>
              <p className="text-xs text-muted-foreground">The Living Identity Protocol</p>
            </div>
          </div>
          
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {/* Profile Card */}
        <div className="bg-card border border-border rounded-xl p-6 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-20 h-20 relative">
              <DNAHelix />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-foreground">{username}</h2>
              <p className="text-sm text-muted-foreground">{user.email}</p>
              <div className="flex flex-wrap gap-2 mt-2">
                <span className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full border border-primary/30">
                  Generation 1
                </span>
                <span className="px-2 py-1 text-xs bg-card text-muted-foreground rounded-full border border-border">
                  Born {birthDate}
                </span>
              </div>
            </div>
            <div className="text-right hidden sm:block">
              <div className="text-2xl font-bold text-primary">23</div>
              <div className="text-xs text-muted-foreground">Active Chromosomes</div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 bg-card border border-border rounded-lg p-1 mb-6 overflow-x-auto">
          {[
            { id: "overview", label: "Overview", icon: Activity },
            { id: "messages", label: "Messages", icon: MessageSquare },
            { id: "genes", label: "Genes", icon: Dna },
            { id: "settings", label: "Settings", icon: Settings },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors flex-1 sm:flex-none justify-center ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-background"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard
                icon={Shield}
                label="Security Level"
                value="99.7%"
                color="text-primary"
              />
              <StatCard
                icon={Zap}
                label="Evolution Rate"
                value="Active"
                color="text-amber-500"
              />
              <StatCard
                icon={Users}
                label="Connections"
                value="0"
                color="text-cyan-500"
              />
              <StatCard
                icon={Lock}
                label="ZK Proofs"
                value="Ready"
                color="text-violet-500"
              />
            </div>

            {/* Chromosome Visualization */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-bold text-foreground mb-4">Chromosome Activity</h3>
              <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2">
                {chromosomes.map((chr) => (
                  <div key={chr.id} className="text-center">
                    <div
                      className="w-full aspect-square rounded-lg mb-1 relative overflow-hidden"
                      style={{ backgroundColor: `${chr.color}20` }}
                    >
                      <div
                        className="absolute bottom-0 left-0 right-0 transition-all duration-1000"
                        style={{
                          height: `${chr.activity}%`,
                          backgroundColor: chr.color,
                          opacity: 0.6,
                        }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground">{chr.id}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <ActionCard
                icon={Globe}
                title="Mesh Network"
                description="Join the decentralized network to relay messages and earn rewards"
                action="Connect"
              />
              <ActionCard
                icon={Dna}
                title="Express Genes"
                description="Activate traits and capabilities in your genetic identity"
                action="Configure"
              />
            </div>
          </div>
        )}

        {activeTab === "messages" && (
          <div className="bg-card border border-border rounded-xl p-8 text-center">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-bold text-foreground mb-2">No Messages Yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Start a conversation with another CrypId to begin secure messaging
            </p>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Find Contacts
            </Button>
          </div>
        )}

        {activeTab === "genes" && (
          <div className="space-y-4">
            <GeneCard
              name="Privacy Level"
              description="Controls how much information is revealed in interactions"
              level={40}
              active={true}
            />
            <GeneCard
              name="Mesh Participation"
              description="Relay messages through the network and earn ADN tokens"
              level={0}
              active={false}
            />
            <GeneCard
              name="Quantum Resistance"
              description="Post-quantum cryptography using CRYSTALS-Kyber"
              level={100}
              active={true}
            />
            <GeneCard
              name="Mutation Rate"
              description="How quickly your identity evolves with each interaction"
              level={50}
              active={true}
            />
          </div>
        )}

        {activeTab === "settings" && (
          <div className="space-y-4">
            <SettingsCard
              title="Account Security"
              description="Manage your password and DNA recovery key"
            />
            <SettingsCard
              title="Privacy Preferences"
              description="Control what information is shared with contacts"
            />
            <SettingsCard
              title="Blockchain Anchoring"
              description="Configure Frequency chain integration"
            />
            <SettingsCard
              title="Export Identity"
              description="Backup your CrypId-ADN to a secure location"
            />
          </div>
        )}
      </main>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, color }: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  color: string
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <Icon className={`w-5 h-5 ${color} mb-2`} />
      <div className="text-xl font-bold text-foreground">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  )
}

function ActionCard({ icon: Icon, title, description, action }: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
  action: string
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-foreground text-sm">{title}</h4>
        <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
      </div>
      <button className="text-primary text-sm font-medium flex items-center gap-1 flex-shrink-0">
        {action}
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  )
}

function GeneCard({ name, description, level, active }: {
  name: string
  description: string
  level: number
  active: boolean
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-medium text-foreground">{name}</h4>
        <span className={`px-2 py-0.5 text-xs rounded-full ${
          active 
            ? "bg-primary/10 text-primary border border-primary/30" 
            : "bg-muted text-muted-foreground border border-border"
        }`}>
          {active ? "Active" : "Inactive"}
        </span>
      </div>
      <p className="text-xs text-muted-foreground mb-3">{description}</p>
      <div className="h-2 bg-background rounded-full overflow-hidden">
        <div
          className="h-full bg-primary transition-all duration-500"
          style={{ width: `${level}%` }}
        />
      </div>
    </div>
  )
}

function SettingsCard({ title, description }: {
  title: string
  description: string
}) {
  return (
    <button className="w-full bg-card border border-border rounded-xl p-4 flex items-center justify-between text-left hover:border-primary/50 transition-colors">
      <div>
        <h4 className="font-medium text-foreground">{title}</h4>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <ChevronRight className="w-5 h-5 text-muted-foreground" />
    </button>
  )
}
