"use client"

import { useEffect, useRef } from "react"

export function DNAHelix() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = 200
    const height = 120
    canvas.width = width
    canvas.height = height

    let animationId: number
    let time = 0

    const draw = () => {
      ctx.clearRect(0, 0, width, height)
      
      const centerY = height / 2
      const amplitude = 25
      const frequency = 0.05
      const spacing = 15

      // Draw connecting lines
      for (let x = 0; x < width; x += spacing) {
        const y1 = centerY + Math.sin((x + time) * frequency) * amplitude
        const y2 = centerY - Math.sin((x + time) * frequency) * amplitude
        
        ctx.beginPath()
        ctx.moveTo(x, y1)
        ctx.lineTo(x, y2)
        ctx.strokeStyle = `rgba(34, 197, 94, ${0.3 + Math.abs(Math.sin((x + time) * frequency)) * 0.4})`
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw helix strands
      ctx.beginPath()
      for (let x = 0; x < width; x++) {
        const y = centerY + Math.sin((x + time) * frequency) * amplitude
        if (x === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }
      ctx.strokeStyle = "rgba(34, 197, 94, 1)"
      ctx.lineWidth = 3
      ctx.stroke()

      ctx.beginPath()
      for (let x = 0; x < width; x++) {
        const y = centerY - Math.sin((x + time) * frequency) * amplitude
        if (x === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }
      ctx.strokeStyle = "rgba(34, 197, 94, 1)"
      ctx.lineWidth = 3
      ctx.stroke()

      // Draw nodes
      for (let x = 0; x < width; x += spacing) {
        const y1 = centerY + Math.sin((x + time) * frequency) * amplitude
        const y2 = centerY - Math.sin((x + time) * frequency) * amplitude
        
        // Outer glow
        ctx.beginPath()
        ctx.arc(x, y1, 6, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(34, 197, 94, 0.3)"
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(x, y1, 4, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(34, 197, 94, 1)"
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(x, y2, 6, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(16, 185, 129, 0.3)"
        ctx.fill()
        
        ctx.beginPath()
        ctx.arc(x, y2, 4, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(16, 185, 129, 1)"
        ctx.fill()
      }

      time += 1.5
      animationId = requestAnimationFrame(draw)
    }

    draw()

    return () => {
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="w-[200px] h-[120px]"
      style={{ imageRendering: "crisp-edges" }}
    />
  )
}
