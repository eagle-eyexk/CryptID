"use client"

import { Shield, Eye, Fingerprint } from "lucide-react"

const features = [
  { icon: Shield, label: "End-to-End Encrypted" },
  { icon: Eye, label: "Zero-Knowledge" },
  { icon: Fingerprint, label: "Self-Sovereign" },
]

export function FeatureBadges() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
      {features.map((feature, index) => (
        <div
          key={index}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-card border-2 border-primary/20 text-sm text-foreground font-medium shadow-sm hover:border-primary/40 hover:shadow-md hover:shadow-primary/10 transition-all duration-300"
        >
          <feature.icon className="w-4 h-4 text-primary" />
          <span>{feature.label}</span>
        </div>
      ))}
    </div>
  )
}
