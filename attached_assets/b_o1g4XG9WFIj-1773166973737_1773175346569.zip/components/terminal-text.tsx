"use client"

import { useState, useEffect } from "react"

const terminalLines = [
  "> INITIALIZING GENETIC IDENTITY PROTOCOL...",
  "> SECURE CHANNEL ESTABLISHED",
  "> READY TO BIRTH YOUR CRYPID",
]

export function TerminalText() {
  const [displayedLines, setDisplayedLines] = useState<string[]>([])
  const [currentLine, setCurrentLine] = useState(0)
  const [currentChar, setCurrentChar] = useState(0)
  const [showCursor, setShowCursor] = useState(true)

  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor((prev) => !prev)
    }, 530)
    return () => clearInterval(cursorInterval)
  }, [])

  useEffect(() => {
    if (currentLine >= terminalLines.length) return

    const line = terminalLines[currentLine]
    
    if (currentChar < line.length) {
      const timeout = setTimeout(() => {
        setDisplayedLines((prev) => {
          const newLines = [...prev]
          newLines[currentLine] = line.slice(0, currentChar + 1)
          return newLines
        })
        setCurrentChar((prev) => prev + 1)
      }, 30)
      return () => clearTimeout(timeout)
    } else {
      const timeout = setTimeout(() => {
        setCurrentLine((prev) => prev + 1)
        setCurrentChar(0)
      }, 500)
      return () => clearTimeout(timeout)
    }
  }, [currentLine, currentChar])

  return (
    <div className="w-full max-w-lg bg-card border-2 border-primary/20 rounded-xl p-4 font-mono text-xs md:text-sm shadow-lg shadow-primary/5">
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-border">
        <div className="w-3 h-3 rounded-full bg-red-400" />
        <div className="w-3 h-3 rounded-full bg-amber-400" />
        <div className="w-3 h-3 rounded-full bg-primary" />
        <span className="ml-2 text-xs text-muted-foreground">terminal</span>
      </div>
      <div className="space-y-1 text-left">
        {displayedLines.map((line, index) => (
          <p key={index} className="text-primary font-semibold">
            {line}
            {index === currentLine - 1 || (index === displayedLines.length - 1 && currentLine < terminalLines.length) ? null : null}
          </p>
        ))}
        {currentLine < terminalLines.length && (
          <span className={`inline-block w-2 h-5 bg-primary rounded-sm ml-0.5 ${showCursor ? "opacity-100" : "opacity-0"}`} />
        )}
        {currentLine >= terminalLines.length && (
          <span className={`inline-block w-2 h-5 bg-primary rounded-sm ${showCursor ? "opacity-100" : "opacity-0"}`} />
        )}
      </div>
    </div>
  )
}
