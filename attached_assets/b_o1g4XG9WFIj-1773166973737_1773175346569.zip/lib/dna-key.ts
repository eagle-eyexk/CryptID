// CrypId-ADN Key Generation System
// Generates unique DNA-based recovery keys using cryptographic entropy

const DNA_BASES = ['A', 'T', 'G', 'C'] as const
const CODON_WORDS: Record<string, string> = {
  'AAA': 'ALPHA', 'AAT': 'BETA', 'AAG': 'GAMMA', 'AAC': 'DELTA',
  'ATA': 'ECHO', 'ATT': 'FOXTROT', 'ATG': 'GOLF', 'ATC': 'HOTEL',
  'AGA': 'INDIA', 'AGT': 'JULIET', 'AGG': 'KILO', 'AGC': 'LIMA',
  'ACA': 'MIKE', 'ACT': 'NOVEMBER', 'ACG': 'OSCAR', 'ACC': 'PAPA',
  'TAA': 'QUEBEC', 'TAT': 'ROMEO', 'TAG': 'SIERRA', 'TAC': 'TANGO',
  'TTA': 'UNIFORM', 'TTT': 'VICTOR', 'TTG': 'WHISKEY', 'TTC': 'XRAY',
  'TGA': 'YANKEE', 'TGT': 'ZULU', 'TGG': 'APEX', 'TGC': 'BEACON',
  'TCA': 'CIPHER', 'TCT': 'DYNAMO', 'TCG': 'EMBER', 'TCC': 'FLUX',
  'GAA': 'GENESIS', 'GAT': 'HELIX', 'GAG': 'ION', 'GAC': 'JADE',
  'GTA': 'KINETIC', 'GTT': 'LATTICE', 'GTG': 'MATRIX', 'GTC': 'NEXUS',
  'GGA': 'OMEGA', 'GGT': 'PRISM', 'GGG': 'QUANTUM', 'GGC': 'RADIX',
  'GCA': 'SPARK', 'GCT': 'TENSOR', 'GCG': 'UMBRA', 'GCC': 'VERTEX',
  'CAA': 'WAVE', 'CAT': 'XENON', 'CAG': 'YIELD', 'CAC': 'ZERO',
  'CTA': 'ABYSS', 'CTT': 'BLAZE', 'CTG': 'CROWN', 'CTC': 'DRIFT',
  'CGA': 'EPOCH', 'CGT': 'FABLE', 'CGG': 'GLYPH', 'CGC': 'HAVEN',
  'CCA': 'IVORY', 'CCT': 'JEWEL', 'CCG': 'KARMA', 'CCC': 'LUMEN',
}

export interface DNAKey {
  sequence: string      // Raw DNA sequence (e.g., "ATGCTAGC...")
  codons: string[]      // Array of 3-letter codons
  words: string[]       // Human-readable word representation
  displayKey: string    // Formatted display string
  hash: string          // SHA-256 hash for storage
}

// Generate cryptographically secure random bytes
function getRandomBytes(length: number): Uint8Array {
  if (typeof window !== 'undefined' && window.crypto) {
    return window.crypto.getRandomValues(new Uint8Array(length))
  }
  // Fallback for server-side
  const bytes = new Uint8Array(length)
  for (let i = 0; i < length; i++) {
    bytes[i] = Math.floor(Math.random() * 256)
  }
  return bytes
}

// Convert bytes to DNA bases (2 bits per base)
function bytesToDNA(bytes: Uint8Array): string {
  let dna = ''
  for (const byte of bytes) {
    // Each byte gives us 4 DNA bases
    dna += DNA_BASES[(byte >> 6) & 0x03]
    dna += DNA_BASES[(byte >> 4) & 0x03]
    dna += DNA_BASES[(byte >> 2) & 0x03]
    dna += DNA_BASES[byte & 0x03]
  }
  return dna
}

// Split DNA sequence into codons (3-letter groups)
function sequenceToCodons(sequence: string): string[] {
  const codons: string[] = []
  for (let i = 0; i < sequence.length; i += 3) {
    if (i + 3 <= sequence.length) {
      codons.push(sequence.slice(i, i + 3))
    }
  }
  return codons
}

// Convert codons to human-readable words
function codonsToWords(codons: string[]): string[] {
  return codons.map(codon => CODON_WORDS[codon] || 'UNKNOWN')
}

// SHA-256 hash function
async function sha256(message: string): Promise<string> {
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const msgBuffer = new TextEncoder().encode(message)
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
  }
  // Simple fallback hash for SSR (not cryptographically secure, just for display)
  let hash = 0
  for (let i = 0; i < message.length; i++) {
    const char = message.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return Math.abs(hash).toString(16).padStart(64, '0')
}

// Generate a new DNA recovery key
export async function generateDNAKey(): Promise<DNAKey> {
  // Generate 24 random bytes = 96 DNA bases = 32 codons = 32 words
  // Using 8 words for the recovery key (24 bases = 6 bytes)
  const bytes = getRandomBytes(6)
  const sequence = bytesToDNA(bytes)
  const codons = sequenceToCodons(sequence)
  const words = codonsToWords(codons)
  
  // Create display format: 8 words in 2 groups of 4
  const displayKey = `${words.slice(0, 4).join('-')}\n${words.slice(4, 8).join('-')}`
  
  // Hash the sequence for secure storage
  const hash = await sha256(sequence)
  
  return {
    sequence,
    codons,
    words,
    displayKey,
    hash,
  }
}

// Validate a DNA key input and return its hash
export async function validateDNAKey(input: string): Promise<{ valid: boolean; hash: string | null }> {
  // Clean up input - handle both word format and raw DNA
  const cleanInput = input.toUpperCase().trim()
  
  // Check if it's word format
  const words = cleanInput.split(/[-\s\n]+/).filter(w => w.length > 0)
  
  if (words.length === 8) {
    // Convert words back to DNA sequence
    const reverseMap: Record<string, string> = {}
    for (const [codon, word] of Object.entries(CODON_WORDS)) {
      reverseMap[word] = codon
    }
    
    const codons = words.map(w => reverseMap[w])
    if (codons.some(c => !c)) {
      return { valid: false, hash: null }
    }
    
    const sequence = codons.join('')
    const hash = await sha256(sequence)
    return { valid: true, hash }
  }
  
  // Check if it's raw DNA format
  if (/^[ATGC]+$/.test(cleanInput) && cleanInput.length === 24) {
    const hash = await sha256(cleanInput)
    return { valid: true, hash }
  }
  
  return { valid: false, hash: null }
}

// Generate chromosome visualization data
export function generateChromosomeData(): { id: number; color: string; activity: number }[] {
  return Array.from({ length: 23 }, (_, i) => ({
    id: i + 1,
    color: `hsl(${(i * 15) + 120}, 70%, 50%)`,
    activity: Math.random() * 100,
  }))
}
